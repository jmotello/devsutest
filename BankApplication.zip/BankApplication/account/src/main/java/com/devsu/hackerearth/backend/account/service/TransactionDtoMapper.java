package com.devsu.hackerearth.backend.account.service;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TransactionDtoMapper {

    TransactionDto toTransactionDto(Transaction transaction);

    Transaction toTransactionEntity(TransactionDto transactionDto);


}
