package com.devsu.hackerearth.backend.client.model.dto;

import lombok.*;

@Data
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class PartialClientDto {

    private Boolean isActive;
}
