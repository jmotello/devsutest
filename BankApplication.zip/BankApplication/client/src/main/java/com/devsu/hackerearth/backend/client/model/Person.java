package com.devsu.hackerearth.backend.client.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
@Getter
@Setter
public class Person extends Base {
	private String name;
	private String dni;
	private String gender;
	private Integer age;
	private String address;
	private String phone;
}
