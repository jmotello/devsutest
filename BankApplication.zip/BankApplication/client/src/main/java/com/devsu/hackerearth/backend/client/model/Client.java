package com.devsu.hackerearth.backend.client.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;

@Entity
@Getter
@Setter
public class Client extends Person {
	private String password;
	private Boolean isActive;
}
