package com.devsu.hackerearth.backend.account.service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class ClientEventListener {

    private final AccountRepository accountRepository;

    public ClientEventListener(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }
    @KafkaListener(topics = "${kafka.topic.name}", groupId = "${kafka.consumer.group-id}")
    public void handleClientCreated(ClientDto clientDto) {
        Account account = new Account();
        account.setClientId(clientDto.getId());
        account.setNumber(clientDto.getName() + "123");
        account.setType("SAVINGS");
        account.setInitialAmount(0.0);
        account.setIsActive(true);

        accountRepository.save(account);
    }

}