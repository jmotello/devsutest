package com.devsu.hackerearth.backend.client;

import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;
import com.devsu.hackerearth.backend.client.service.ClientService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class ClientIntegrationTest {

	@LocalServerPort
	private int port;

	@Autowired
	private TestRestTemplate restTemplate;

	@Autowired
	private ClientService clientService;

	@Autowired
	private ClientRepository clientRepository;

	private String baseUrl;

	@BeforeEach
	void setUp() {
		baseUrl = "http://localhost:" + port + "/api/clients";
		clientRepository.deleteAll();
	}

	@Test
	void testGetClientById() {
		ClientDto savedClient = clientService.create(new ClientDto(null, "12345678", "Jhonny", "password123", "M", 30, "123 Main St", "55281234", true));
		Long id = savedClient.getId();

		ResponseEntity<ClientDto> response = restTemplate.exchange(
				baseUrl + "/" + id,
				HttpMethod.GET,
				null,
				ClientDto.class
		);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(response.getBody()).isNotNull();
		assertThat(response.getBody().getId()).isEqualTo(id);
		assertThat(response.getBody().getDni()).isEqualTo("12345678");
		assertThat(response.getBody().getName()).isEqualTo("Jhonny");
		assertThat(response.getBody().getAge()).isEqualTo(30);
	}

}
