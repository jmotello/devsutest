package com.devsu.hackerearth.backend.account.model.dto;

import lombok.*;

@Data
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class PartialAccountDto {

	private Boolean isActive;
}
