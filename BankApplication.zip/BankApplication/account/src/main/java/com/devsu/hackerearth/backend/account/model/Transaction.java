package com.devsu.hackerearth.backend.account.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Transaction extends Base {

	private Date date;
	private String type;
	private Double amount;
	private Double balance;

	@Column(name = "account_id")
	private Long accountId;
}
