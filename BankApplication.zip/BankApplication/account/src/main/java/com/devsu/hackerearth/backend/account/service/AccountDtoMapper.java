package com.devsu.hackerearth.backend.account.service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AccountDtoMapper {

    AccountDto toAccountDto(Account account);

    Account toAccountEntity(AccountDto accountDto);


}
