package com.devsu.hackerearth.backend.account.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@AllArgsConstructor
@Getter
@Setter
public class AccountDto {

	private Long id;
	private String number;
	private String type;
	private Double initialAmount;
	private Boolean isActive;
	private Long clientId;
}
