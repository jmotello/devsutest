package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import com.devsu.hackerearth.backend.account.exceptions.BadRequestException;
import com.devsu.hackerearth.backend.account.model.Account;
import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

import javax.persistence.EntityNotFoundException;

@Service
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepository;

    private final AccountDtoMapper accountDtoMapper;

	public AccountServiceImpl(AccountRepository accountRepository, AccountDtoMapper accountDtoMapper) {
		this.accountRepository = accountRepository;
        this.accountDtoMapper = accountDtoMapper;
	}

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        return accountRepository.findAll()
                .stream()
                .map(accountDtoMapper::toAccountDto)
                .collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        if (id == null)
            throw new BadRequestException("id cannot be null");

        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Account not found " + id));

        return accountDtoMapper.toAccountDto(account);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
        if (accountDto.getNumber() == null)
            throw new BadRequestException("Number cannot be null");

        if (accountDto.getType() == null)
            throw new BadRequestException("Type cannot be null");

        if (accountDto.getInitialAmount() == null)
            throw new BadRequestException("InitialAmount cannot be null");

        if (accountDto.getIsActive() == null)
            throw new BadRequestException("IsActive cannot be null");

        if (accountDto.getClientId() == null)
            throw new BadRequestException("ClientId cannot be null");

        return accountDtoMapper.toAccountDto(accountRepository.save(accountDtoMapper.toAccountEntity(accountDto)));
    }

    @Override
    public AccountDto update(Long id, AccountDto accountDto) {
        // Update account
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Account not found " + id));

        account.setId(id);
        account.setNumber(accountDto.getNumber());
        account.setType(accountDto.getType());
        account.setInitialAmount(accountDto.getInitialAmount());
        account.setIsActive(accountDto.getIsActive());
        account.setClientId(accountDto.getClientId());

        Account updatedAccount = accountRepository.save(account);
        return accountDtoMapper.toAccountDto(updatedAccount);
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Account not found " + id));

        if (partialAccountDto.getIsActive() != null) {
            account.setIsActive(partialAccountDto.getIsActive());
        }
        account.setId(id);
        Account updatedAccount = accountRepository.save(account);
        return accountDtoMapper.toAccountDto(updatedAccount);
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        accountRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Account not found " + id));

        accountRepository.deleteById(id);
    }
    
}
