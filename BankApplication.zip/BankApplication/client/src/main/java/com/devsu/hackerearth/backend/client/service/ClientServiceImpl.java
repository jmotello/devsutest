package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import com.devsu.hackerearth.backend.client.exceptions.BadRequestException;
import com.devsu.hackerearth.backend.client.model.Client;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

import javax.persistence.EntityNotFoundException;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	private final ClientDtoMapper clientDtoMapper;

	private final KafkaTemplate<String, Object> kafkaTemplate;

	@Value("${kafka.topic.name}")
	private String createAccount;

	public ClientServiceImpl(ClientRepository clientRepository, ClientDtoMapper clientDtoMapper, KafkaTemplate<String, Object> kafkaTemplate) {
		this.clientRepository = clientRepository;
		this.clientDtoMapper = clientDtoMapper;
		this.kafkaTemplate = kafkaTemplate;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		return clientRepository.findAll()
					.stream()
					.map(clientDtoMapper::toClientDto)
					.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		if (id == null)
			throw new BadRequestException("id cannot be null");

		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Client not found " + id));

		return clientDtoMapper.toClientDto(client);

	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		if (clientDto.getName() == null)
			throw new BadRequestException("Name cannot be null");

		if (clientDto.getDni() == null)
			throw new BadRequestException("Dni cannot be null");

		if (clientDto.getGender() == null)
			throw new BadRequestException("Gender cannot be null");

		if (clientDto.getAge() == null)
			throw new BadRequestException("Age cannot be null");

		if (clientDto.getPhone() == null)
			throw new BadRequestException("Phone cannot be null");

		if (clientDto.getAddress() == null)
			throw new BadRequestException("Address cannot be null");

		if (clientDto.getPassword() == null)
			throw new BadRequestException("Password cannot be null");

		if (clientDto.getIsActive() == null)
			throw new BadRequestException("IsActive cannot be null");

		ClientDto clientDtoSent = clientDtoMapper.toClientDto(clientRepository.save(clientDtoMapper.toClientEntity(clientDto)));

		kafkaTemplate.send(createAccount, clientDtoSent);

		return clientDtoSent;
	}

	@Override
	public ClientDto update(Long id, ClientDto clientDto) {
		// Update client
		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Client not found " + id));

		client.setId(id);
		client.setName(clientDto.getName());
		client.setDni(clientDto.getDni());
		client.setGender(clientDto.getGender());
		client.setAge(clientDto.getAge());
		client.setPhone(clientDto.getPhone());
		client.setAddress(clientDto.getAddress());
		client.setPassword(clientDto.getPassword());
		client.setIsActive(clientDto.getIsActive());

		Client updatedClient = clientRepository.save(client);
		return clientDtoMapper.toClientDto(updatedClient);

	}

	@Override
    public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
        // Partial update account

		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Client not found " + id));

		if (partialClientDto.getIsActive() != null) {
			client.setIsActive(partialClientDto.getIsActive());
		}

		client.setId(id);
		Client updatedClient = clientRepository.save(client);
		return clientDtoMapper.toClientDto(updatedClient);
    }

	@Override
	public void deleteById(Long id) {
		// Delete client

		clientRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Client not found " + id));

		clientRepository.deleteById(id);
	}
}
