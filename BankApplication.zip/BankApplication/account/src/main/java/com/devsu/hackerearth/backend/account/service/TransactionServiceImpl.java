package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.devsu.hackerearth.backend.account.exceptions.BadRequestException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.AccountStatementDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

import javax.persistence.EntityNotFoundException;

@Service
public class TransactionServiceImpl implements TransactionService {

	private final TransactionRepository transactionRepository;

    private final TransactionDtoMapper transactionDtoMapper;

    private final AccountRepository accountRepository;

	public TransactionServiceImpl(TransactionRepository transactionRepository, TransactionDtoMapper transactionDtoMapper, AccountRepository accountRepository) {
		this.transactionRepository = transactionRepository;
        this.transactionDtoMapper = transactionDtoMapper;
        this.accountRepository = accountRepository;
	}

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        return transactionRepository.findAll()
                .stream()
                .map(transactionDtoMapper::toTransactionDto)
                .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        if (id == null)
            throw new BadRequestException("id cannot be null");

        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Transaction not found " + id));

        return transactionDtoMapper.toTransactionDto(transaction);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        if (transactionDto.getAmount() == null)
            throw new BadRequestException("Amount cannot be null");

        if (transactionDto.getAccountId() == null)
            throw new BadRequestException("AccountId cannot be null");

        if (transactionDto.getAmount() == 0) {
            throw new IllegalArgumentException("Amount cannot be zero");
        }

        if (transactionDto.getType() == null ||
                (!transactionDto.getType().equalsIgnoreCase("DEPOSIT") &&
                        !transactionDto.getType().equalsIgnoreCase("WITHDRAWAL"))) {
            throw new BadRequestException("Invalid transaction type. Must be 'DEPOSIT' or 'WITHDRAWAL'");
        }

        Account account = accountRepository.findById(transactionDto.getAccountId())
                .orElseThrow(() -> new EntityNotFoundException(
                        "Account not found with ID: " + transactionDto.getAccountId())
                );

        Double newBalance = account.getInitialAmount();

        if (transactionDto.getType().equalsIgnoreCase("DEPOSIT")) {
            newBalance += transactionDto.getAmount();
        } else if (transactionDto.getType().equalsIgnoreCase("WITHDRAWAL")) {
            if (newBalance < transactionDto.getAmount()) {
                throw new IllegalStateException("Saldo no disponible");
            }
            newBalance -= transactionDto.getAmount();
        }

        Transaction transaction = transactionDtoMapper.toTransactionEntity(transactionDto);
        transaction.setBalance(newBalance);
        transaction.setDate(new Date());
        Transaction savedTransaction = transactionRepository.save(transaction);
        account.setInitialAmount(newBalance);
        accountRepository.save(account);

        return transactionDtoMapper.toTransactionDto(savedTransaction);

    }

    @Override
    public List<AccountStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report
        if (dateTransactionStart.after(dateTransactionEnd)) {
            throw new IllegalArgumentException("Start date must be before end date.");
        }

        List<Account> accounts = accountRepository.findByClientId(clientId);
        if (accounts.isEmpty()) {
            throw new EntityNotFoundException("No accounts found for client id " + clientId);
        }

        List<AccountStatementDto> report = new ArrayList<>();

        for (Account account : accounts) {
            List<Transaction> transactions = transactionRepository.findByClientIdAndTransactionDateBetween(
                    account.getId(), dateTransactionStart, dateTransactionEnd);

            List<TransactionDto> transactionDtos = transactions.stream()
                    .map(transaction -> new TransactionDto(
                            transaction.getId(),
                            transaction.getDate(),
                            transaction.getType(),
                            transaction.getAmount(),
                            transaction.getBalance(),
                            transaction.getAccountId()
                    )).collect(Collectors.toList());

            AccountStatementDto accountDto = new AccountStatementDto(
                    account.getNumber(),
                    account.getType(),
                    account.getInitialAmount(),
                    account.getIsActive(),
                    transactionDtos
            );

            report.add(accountDto);
        }

		return report;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
		return null;
    }
    
}
