package com.devsu.hackerearth.backend.client.service;

import com.devsu.hackerearth.backend.client.model.Base;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface ClientDtoMapper {

    default Long mapId(Base base) {
        return base.getId();
    }

    default void mapId(ClientDto clientDto, @MappingTarget Client client) {
        client.setId(clientDto.getId());
    }


    @Mapping(source = "id", target = "id")
    ClientDto toClientDto(Client client);

    @Mapping(source = "id", target = "id")
    Client toClientEntity(ClientDto clientDto);


}
